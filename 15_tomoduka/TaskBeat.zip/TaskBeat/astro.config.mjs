// @ts-check
import { defineConfig } from 'astro/config';

// https://astro.build/config

// astro.config.mjs
export default {
  output: "static"
};